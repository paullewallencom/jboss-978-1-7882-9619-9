package com.beosbank.jbdevg.jbossas.dao.ifc;

import com.beosbank.jbdevg.jbossas.domain.MoneyTransfert;

public interface IMoneyTransfertEjb {

	public long addMoneyTransfer(MoneyTransfert mt);
}
