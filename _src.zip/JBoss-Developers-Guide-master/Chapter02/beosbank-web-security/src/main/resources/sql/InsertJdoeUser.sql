INSERT INTO `T_ACCOUNT`(`username`,`password`,`role`) 
VALUES ('jdoe','${CRYPT}amJvc3M=${CRYPT}','Customer')